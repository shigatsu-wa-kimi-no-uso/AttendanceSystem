﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttendanceSystemUI.Entities
{
	public enum UserRole
	{
		NORMAL_EMPLOYEE = 0,
		ADMIN = 1,
		INTERN = 2
	}
}
