﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttendanceSystemUI.Entities
{
	public enum GuestAction
	{
		LOGIN = 0,
		LOGOUT = 1
	}
}
